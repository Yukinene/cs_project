<?php
header("location:view/home_page/home.php");
?>