</div>
</main>
</body>
<footer class="bg-light bg-gradient mt-auto text-muted">
  <div class="container py-3">
    <div class="row g-0">
      <div class="col-sm-6 col-md-8">
        <address>
        <p class="mb-1"><strong>ร้านภูมินทร์การค้า</strong>
        <br>
        <p class="mb-0">119/451 หมู่บ้านอัมรินทร์นิเวศน์ 3 ผัง 4 ถนนสายไหม
        เขตสายไหม แขวงสายไหม จ.กรุงเทพมหานคร 10220</p>
        <p class="mb-0"><abbr title="Phone" class="initialism">โทรศัพท์:</abbr> (+66) 80 254 5728</p>
        <p class="mb-0"><abbr title="Email" class="initialism">อีเมล:</abbr> 
        <a href="mailto:pumin.s@ku.th" class="btn btn-light">pumin.s@ku.th</a></p>
        </address>
      </div>
    </div>
    <p class="float-end mb-1 ">
        <a href="#" class="btn btn-outline-info">กลับไปข้างบน</a>
        <!-- Back to top -->
    </p>
  </div>
</footer>
</html>