<?php
if (count($completes) > 0) {
	foreach ($completes as $complete) {
		echo "<script>alert('$complete');</script>";
	}
}
?>