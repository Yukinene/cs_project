<?php
    // connect to the database
    $db = mysqli_connect('localhost', 'root', '', 'cs_project_db');
?>