<?php
    //nla = no longer available
?>

<div class="mt-2 col-12">
    <div class="card alert alert-danger text-center">
        <div class="card-body">
            <h3 class="card-title">สินค้าหมดชั่วคราว</h3>
        </div>
    </div>
</div>