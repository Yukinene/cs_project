<?php
require '../../inc/header.php';
checkuser();
?>
<title>จัดการคำสั่งซื้อ</title>
<?php
include '../order_page/order_list.php';
require '../../inc/footer.php';
?>