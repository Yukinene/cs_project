<?php
require '../../inc/header.php';
checkadmin();
?>
<title>ระบบจัดการคำสั่งซื้อ (สำหรับผู้จัดการระบบ)</title>
<?php
include '../order_page/order_list.php';
require '../../inc/footer.php';
?>