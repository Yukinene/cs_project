<div class="row mb-2">
    <div class="col-6 border border-dark">
        <?php include 'table/admin_freight_list.php'; ?>
    </div>
</div>

<?php
// Note
// ค่าขนส่ง
// เมื่ออยู่แถวกรุงเทพฯและปริมณฑล(นครปฐม นนทบุรี ปทุมธานี สมุครปราการ สมุครสาคร) 40 บาท
// ต่างจังหวัด 60 บาท
?>