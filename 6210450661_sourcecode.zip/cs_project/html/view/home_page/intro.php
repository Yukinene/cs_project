  <!-- Background image -->
  <div
    class=" text-center align-middle bg-image"
    style="
      background-image: url('../../images/homepage-hd-wallpaper.jpg');
      height: 100vh;
    "
  >
    <div class="mask">
      <div class="d-flex justify-content-center align-items-center h-100">
        <div class="text-black">
          <h1 class="fs-1 mb-3">ภูมินทร์การค้า</h1>
          <h4 class="fs-1 mb-3">ถั่วเคลือบมะม่วงเคลือบ</h4>
          <a
            class="btn btn-outline-dark btn-lg m-2"
            href="../../util/registration/login.php">
            เข้าสู่ระบบ
            </a>
          <a
            class="btn btn-outline-dark btn-lg m-2"
            href="../../util/registration/consent_form.php"
          >สมัครสมาชิก</a>
        </div>
      </div>
    </div>
  </div>
  <!-- Background image -->